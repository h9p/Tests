# frozen_string_literal: true

require 'dotenv/load'
require 'telegram/bot'
