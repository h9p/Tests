# frozen_string_literal: true

module Telegram
  module Bot
    module Types
      include Dry.Types()
    end
  end
end
