# frozen_string_literal: true

module Telegram
  module Bot
    module Exceptions
      class Base < StandardError; end
    end
  end
end
