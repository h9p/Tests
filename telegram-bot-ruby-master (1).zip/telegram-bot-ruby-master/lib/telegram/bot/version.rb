# frozen_string_literal: true

module Telegram
  module Bot
    VERSION = '1.0.0'
  end
end
