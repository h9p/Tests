# frozen_string_literal: true

module Telegram
  module Bot
    module Types
      class CallbackGame < Base
      end
    end
  end
end
