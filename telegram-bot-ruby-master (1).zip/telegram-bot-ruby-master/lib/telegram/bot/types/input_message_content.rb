# frozen_string_literal: true

module Telegram
  module Bot
    module Types
      class InputMessageContent < Base
      end
    end
  end
end
