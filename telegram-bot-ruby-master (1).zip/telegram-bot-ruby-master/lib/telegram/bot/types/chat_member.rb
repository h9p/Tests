# frozen_string_literal: true

module Telegram
  module Bot
    module Types
      class ChatMember < Base
      end
    end
  end
end
