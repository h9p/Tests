# frozen_string_literal: true

module Telegram
  module Bot
    module Types
      class ForumTopicClosed < Base
      end
    end
  end
end
